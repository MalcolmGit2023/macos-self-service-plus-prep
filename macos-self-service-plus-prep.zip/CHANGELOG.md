# Changelog

All notable changes to this project will be documented in this file.

## [1.0.0] - 2026-01-21
- Initial commit with hide/unhide and Dock removal scripts
- Added README, MIT License, and .gitignore
