#!/bin/bash
/usr/local/bin/dockutil --remove 'Self Service' --allhomes
