mv "/Applications/Self Service.app" "/Applications/.Self Service.app"
